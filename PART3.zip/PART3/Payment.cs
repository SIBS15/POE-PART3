using System.ComponentModel.DataAnnotations;
namespace RaceDay.Api.Models;
public class Payment
{
    public int PaymentId { get; set; }
    public int EnrolmentId { get; set; }
    public Enrolment? Enrolment { get; set; }
    public decimal Amount { get; set; }
    public DateTime PaymentDate { get; set; } = DateTime.Now;
    [Required, MaxLength(20)] public string PaymentMethod { get; set; } = "EFT";
    [Required, MaxLength(20)] public string PaymentStatus { get; set; } = "Pending";
}
