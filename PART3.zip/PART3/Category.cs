using System.ComponentModel.DataAnnotations;
namespace RaceDay.Api.Models;
public class Category
{
    public int CategoryId { get; set; }
    public int EventId { get; set; }
    public RaceEvent? Event { get; set; }
    [Required, MaxLength(50)] public string CategoryName { get; set; } = "";
    public decimal CategoryDistance { get; set; }
    public int MaxParticipants { get; set; } = 500;
    public ICollection<Enrolment> Enrolments { get; set; } = new List<Enrolment>();
}
