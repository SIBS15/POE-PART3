using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
using Microsoft.AspNetCore.Http;
namespace RaceDay.Mvc.Services;
public class RaceDayApiClient(IHttpClientFactory factory, IHttpContextAccessor accessor)
{
    private static readonly JsonSerializerOptions JsonOptions=new(){PropertyNameCaseInsensitive=true};
    private HttpClient Client()=>factory.CreateClient("RaceDayApi");
    private HttpRequestMessage Request(HttpMethod method,string url){
        var req=new HttpRequestMessage(method,url);
        var cookie=accessor.HttpContext?.Session.GetString("ApiSessionCookie");
        if(!string.IsNullOrWhiteSpace(cookie)) req.Headers.TryAddWithoutValidation("Cookie",cookie);
        return req;
    }
    public async Task<HttpResponseMessage> SendAsync(HttpMethod method,string url,object? body=null){
        using var req=Request(method,url); if(body!=null) req.Content=JsonContent.Create(body);
        return await Client().SendAsync(req);
    }
    public async Task<HttpResponseMessage> UploadAsync(string url,IFormFile file){
        using var req=Request(HttpMethod.Post,url);
        using var form=new MultipartFormDataContent();
        await using var stream=file.OpenReadStream();
        using var content=new StreamContent(stream);
        var extension=Path.GetExtension(file.FileName).ToLowerInvariant();
        var contentType=extension switch { ".jpg" or ".jpeg" => "image/jpeg", ".png" => "image/png", ".webp" => "image/webp", _ => file.ContentType };
        if(!string.IsNullOrWhiteSpace(contentType)) content.Headers.ContentType=new MediaTypeHeaderValue(contentType);
        form.Add(content,"file",Path.GetFileName(file.FileName)); req.Content=form;
        return await Client().SendAsync(req);
    }
    public async Task<T?> ReadAsync<T>(HttpResponseMessage response){
        if(!response.IsSuccessStatusCode)return default;
        return await response.Content.ReadFromJsonAsync<T>(JsonOptions);
    }
    public async Task<string> ErrorAsync(HttpResponseMessage response){
        var body=await response.Content.ReadAsStringAsync();
        if(string.IsNullOrWhiteSpace(body)) return $"Request failed ({(int)response.StatusCode}).";
        try { using var document=JsonDocument.Parse(body); if(document.RootElement.TryGetProperty("message",out var message)) return message.GetString() ?? body; } catch(JsonException) { }
        return body;
    }
    public static string? ExtractSessionCookie(HttpResponseMessage response){
        if(!response.Headers.TryGetValues("Set-Cookie",out var values))return null;
        var cookie=values.FirstOrDefault(v=>v.StartsWith(".RaceDay.Session=",StringComparison.OrdinalIgnoreCase));
        return cookie?.Split(';',2)[0];
    }
}
