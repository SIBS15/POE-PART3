using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Models;

namespace RaceDay.Api.Data;

public class RaceDayDbContext(DbContextOptions<RaceDayDbContext> options) : DbContext(options)
{
    public DbSet<AppUser> Users => Set<AppUser>();
    public DbSet<RaceEvent> Events => Set<RaceEvent>();
    public DbSet<Category> Categories => Set<Category>();
    public DbSet<Enrolment> Enrolments => Set<Enrolment>();
    public DbSet<RaceResult> Results => Set<RaceResult>();
    public DbSet<Payment> Payments => Set<Payment>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<AppUser>(e =>
        {
            e.ToTable("Users");
            e.HasKey(x => x.UserId);
            e.Property(x => x.UserId).HasColumnName("UserID");
            e.Property(x => x.Role).HasMaxLength(20).IsUnicode(false).IsRequired();
            e.Property(x => x.FirstName).HasMaxLength(50).IsUnicode(false).IsRequired();
            e.Property(x => x.LastName).HasMaxLength(50).IsUnicode(false).IsRequired();
            e.Property(x => x.Email).HasMaxLength(100).IsUnicode(false).IsRequired();
            e.HasIndex(x => x.Email).IsUnique().HasDatabaseName("UQ_Users_Email");
            e.Property(x => x.PasswordHash).HasMaxLength(255).IsUnicode(false).IsRequired();
            e.Property(x => x.PhoneNumber).HasMaxLength(20).IsUnicode(false);
            e.Property(x => x.ProfileImageUrl).HasMaxLength(1000).IsUnicode(false);
            e.Property(x => x.CreatedAt).HasColumnType("datetime").HasDefaultValueSql("(GETDATE())");
            e.ToTable(t => t.HasCheckConstraint("CK_Users_Role", "[Role] IN ('Organiser','Participant')"));
        });

        modelBuilder.Entity<RaceEvent>(e =>
        {
            e.ToTable("Events");
            e.HasKey(x => x.EventId);
            e.Property(x => x.EventId).HasColumnName("EventID");
            e.Property(x => x.OrganiserId).HasColumnName("OrganiserID");
            e.Property(x => x.EventName).HasMaxLength(100).IsUnicode(false).IsRequired();
            e.Property(x => x.Description).HasMaxLength(500).IsUnicode(false);
            e.Property(x => x.EventDate).HasColumnType("date");
            e.Property(x => x.Location).HasMaxLength(150).IsUnicode(false).IsRequired();
            e.Property(x => x.Distance).HasPrecision(6, 2);
            e.Property(x => x.EventType).HasMaxLength(20).IsUnicode(false).IsRequired();
            e.Property(x => x.BannerImageUrl).HasMaxLength(1000).IsUnicode(false);
            e.Property(x => x.CreatedAt).HasColumnType("datetime").HasDefaultValueSql("(GETDATE())");
            e.ToTable(t => t.HasCheckConstraint("CK_Events_EventType", "[EventType] IN ('Running','Walking','Cycling')"));
            e.HasOne(x => x.Organiser).WithMany(x => x.OrganisedEvents).HasForeignKey(x => x.OrganiserId).OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<Category>(e =>
        {
            e.ToTable("Categories");
            e.HasKey(x => x.CategoryId);
            e.Property(x => x.CategoryId).HasColumnName("CategoryID");
            e.Property(x => x.EventId).HasColumnName("EventID");
            e.Property(x => x.CategoryName).HasMaxLength(50).IsUnicode(false).IsRequired();
            e.Property(x => x.CategoryDistance).HasPrecision(6, 2).IsRequired();
            e.Property(x => x.MaxParticipants).HasDefaultValue(500);
            e.HasOne(x => x.Event).WithMany(x => x.Categories).HasForeignKey(x => x.EventId).OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<Enrolment>(e =>
        {
            e.ToTable("Enrolments");
            e.HasKey(x => x.EnrolmentId);
            e.Property(x => x.EnrolmentId).HasColumnName("EnrolmentID");
            e.Property(x => x.ParticipantId).HasColumnName("ParticipantID");
            e.Property(x => x.EventId).HasColumnName("EventID");
            e.Property(x => x.CategoryId).HasColumnName("CategoryID");
            e.Property(x => x.EnrolledAt).HasColumnName("EnrolmentDate").HasColumnType("datetime").HasDefaultValueSql("(GETDATE())");
            e.Property(x => x.Status).HasMaxLength(20).IsUnicode(false).IsRequired().HasDefaultValue("Confirmed");
            e.HasIndex(x => new { x.ParticipantId, x.EventId }).IsUnique().HasDatabaseName("UQ_Enrolments_Participant_Event");
            e.ToTable(t => t.HasCheckConstraint("CK_Enrolments_Status", "[Status] IN ('Pending','Confirmed','Cancelled')"));
            e.HasOne(x => x.Participant).WithMany(x => x.Enrolments).HasForeignKey(x => x.ParticipantId).OnDelete(DeleteBehavior.Restrict);
            e.HasOne(x => x.Event).WithMany(x => x.Enrolments).HasForeignKey(x => x.EventId).OnDelete(DeleteBehavior.Cascade);
            e.HasOne(x => x.Category).WithMany(x => x.Enrolments).HasForeignKey(x => x.CategoryId).OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<RaceResult>(e =>
        {
            e.ToTable("Results");
            e.HasKey(x => x.ResultId);
            e.Property(x => x.ResultId).HasColumnName("ResultID");
            e.Property(x => x.EnrolmentId).HasColumnName("EnrolmentID");
            e.Property(x => x.FinishTime).HasColumnType("time");
            e.Property(x => x.CapturedByOrganiserId).HasColumnName("CapturedByOrganiserID");
            e.Property(x => x.RecordedAt).HasColumnName("CapturedDate").HasColumnType("datetime").HasDefaultValueSql("(GETDATE())");
            e.HasIndex(x => x.EnrolmentId).IsUnique().HasDatabaseName("UQ_Results_Enrolment");
            e.HasOne(x => x.Enrolment).WithOne(x => x.Result).HasForeignKey<RaceResult>(x => x.EnrolmentId).OnDelete(DeleteBehavior.Cascade);
            e.HasOne(x => x.CapturedByOrganiser).WithMany().HasForeignKey(x => x.CapturedByOrganiserId).OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<Payment>(e =>
        {
            e.ToTable("Payments");
            e.HasKey(x => x.PaymentId);
            e.Property(x => x.PaymentId).HasColumnName("PaymentID");
            e.Property(x => x.EnrolmentId).HasColumnName("EnrolmentID");
            e.Property(x => x.Amount).HasPrecision(8, 2);
            e.Property(x => x.PaymentDate).HasColumnType("datetime").HasDefaultValueSql("(GETDATE())");
            e.Property(x => x.PaymentMethod).HasMaxLength(20).IsUnicode(false).IsRequired();
            e.Property(x => x.PaymentStatus).HasMaxLength(20).IsUnicode(false).IsRequired().HasDefaultValue("Paid");
            e.HasIndex(x => x.EnrolmentId).IsUnique().HasDatabaseName("UQ_Payments_Enrolment");
            e.ToTable(t =>
            {
                t.HasCheckConstraint("CK_Payments_Method", "[PaymentMethod] IN ('Card','EFT','InstantEFT')");
                t.HasCheckConstraint("CK_Payments_Status", "[PaymentStatus] IN ('Pending','Paid','Refunded')");
            });
            e.HasOne(x => x.Enrolment).WithOne(x => x.Payment).HasForeignKey<Payment>(x => x.EnrolmentId).OnDelete(DeleteBehavior.Cascade);
        });

        base.OnModelCreating(modelBuilder);
    }
}
