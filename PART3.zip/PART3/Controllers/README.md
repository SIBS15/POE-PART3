# RaceDay – PROG6212 Part 3 / Final POE

RaceDay is an ASP.NET Core MVC front end consuming the existing Part 2 REST API. The MVC project does not access SQL Server or Azure directly. Data and image operations go through `RaceDay.Api`.

## Solution structure

- `RaceDay.Api` – REST API, EF Core data access, session authentication and Azure Blob upload endpoints.
- `RaceDay.Mvc` – MVC user interface, session-based role navigation and API client.
- `RaceDay.Api.Tests` – API model tests.
- `RaceDay.Api/Migrations` – EF Core database migrations.

## Requirements

- .NET 8 SDK
- SQL Server / SQL Server Express
- Visual Studio 2022 (ASP.NET and web development)
- Docker Desktop with Linux containers and WSL 2 for Docker demonstration
- Azure Storage account for image uploads (optional for local pages without uploads)

## Configure the API

1. Open `RaceDay.Api/appsettings.json` and set `ConnectionStrings:DefaultConnection` for your SQL Server instance.
2. Configure Azure settings using User Secrets or environment variables. Do not commit a real connection string:

```powershell
dotnet user-secrets init --project RaceDay.Api
dotnet user-secrets set "AzureBlobStorage:ConnectionString" "<YOUR AZURE STORAGE CONNECTION STRING>" --project RaceDay.Api
dotnet user-secrets set "AzureBlobStorage:ContainerName" "raceday-images" --project RaceDay.Api
```

3. Apply migrations:

```powershell
dotnet tool install --global dotnet-ef --version 8.0.11
dotnet ef database update --project RaceDay.Api
```

4. Start the API on the host HTTP port used by the MVC app:

```powershell
dotnet run --project RaceDay.Api --urls http://0.0.0.0:5000
```

Swagger is available at `http://localhost:5000/swagger` in Development.

## Run MVC locally

In a second terminal:

```powershell
dotnet run --project RaceDay.Mvc
```

The local MVC API URL is configured in `RaceDay.Mvc/appsettings.json` as `http://localhost:5000/`. Register a Participant and an Organiser account to test both role experiences.

## Docker

Run the following commands from the solution root (the folder containing `RaceDay.sln`):

```powershell
docker build -f RaceDay.Mvc/Dockerfile -t raceday-mvc:part3 .
docker run -d --name raceday-mvc -p 8080:8080 -e ApiSettings__BaseUrl=http://host.docker.internal:5000/ raceday-mvc:part3
```

Open `http://localhost:8080`. Keep the API running on the Windows host at port 5000. Inside Docker, `host.docker.internal` addresses the host; `localhost` would address the MVC container itself.

To inspect or stop the container:

```powershell
docker ps
docker logs raceday-mvc
docker stop raceday-mvc
```

After changing code, remove and rebuild the old container/image:

```powershell
docker rm -f raceday-mvc
docker build -f RaceDay.Mvc/Dockerfile -t raceday-mvc:part3 .
docker run -d --name raceday-mvc -p 8080:8080 -e ApiSettings__BaseUrl=http://host.docker.internal:5000/ raceday-mvc:part3
```

## Implemented Part 3 features

- Registration and login through the Part 2 API; MVC session stores the user identity and role and forwards the API session cookie.
- Organiser dashboard, own-event management, create/edit/delete event, categories, enrolment list and result capture.
- Participant upcoming event search/filter, event detail/category enrolment, My Events, cancellation, My Results and profile update.
- Event banner and profile image upload endpoints in the API. MVC forwards multipart files to the API; the API stores them in Azure Blob Storage and persists image URLs.
- Bootstrap-based responsive sporting UI and distinct role navigation.
- CI workflow restores/builds the full solution, runs API tests and builds the MVC Docker image.

## API endpoint alignment

The MVC app uses the routes implemented in this Part 2 API:
- `POST api/auth/register`, `POST api/auth/login`, `POST api/auth/logout`
- `GET api/events`, `GET api/events/{id}`, `POST/PUT/DELETE api/events`
- `GET/POST api/events/{eventId}/categories`, `DELETE api/categories/{id}`
- `POST api/enrolments`, `GET api/enrolments/me`, `GET api/events/{eventId}/enrolments`, `DELETE api/enrolments/{id}`
- `POST api/enrolments/{enrolmentId}/results`, `GET api/events/{eventId}/results`, `GET api/results/me`
- `GET/PUT api/users/me`, `POST api/events/{id}/banner`, `POST api/users/me/profile-image`

## Rubric checklist and evidence plan\n\nSee [`docs/Part3_Rubric_Checklist.md`](docs/Part3_Rubric_Checklist.md) for the criterion-by-criterion test checklist, evidence list and a suggested sequence of genuine feature commits.\n\n## Before final submission

Run the solution and test both roles against your configured SQL Server and Azure account. The current environment used to prepare these source changes does not contain the .NET SDK, SQL Server or Azure credentials, so a successful compile, database run, blob upload, Docker execution, GitHub Actions run and video recording still need to be performed on your computer. Add your actual GitHub repository link, successful CI screenshot, Docker screenshot and unlisted YouTube video URL here before submitting.

The rubric also requires at least 20 meaningful Git commits. Make commits as features are completed; do not fabricate commit history or screenshots.
