using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Migrations;
using RaceDay.Api.Data;
#nullable disable
namespace RaceDay.Api.Migrations;
[DbContext(typeof(RaceDayDbContext))]
[Migration("20261102090000_AddImageUrls")]
public partial class AddImageUrls : Migration
{
 protected override void Up(MigrationBuilder migrationBuilder){
  migrationBuilder.AddColumn<string>(name:"BannerImageUrl",table:"Events",type:"varchar(1000)",maxLength:1000,nullable:true);
  migrationBuilder.AddColumn<string>(name:"ProfileImageUrl",table:"Users",type:"varchar(1000)",maxLength:1000,nullable:true);
 }
 protected override void Down(MigrationBuilder migrationBuilder){
  migrationBuilder.DropColumn(name:"BannerImageUrl",table:"Events");
  migrationBuilder.DropColumn(name:"ProfileImageUrl",table:"Users");
 }
}
